﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DOAN.Models
{
    public class ChiTietDM
    {
        public int MaDM { get; set; }
        public int SoLuong { get; set; }
        public int Thue { get; set; }
        public int TongCong { get; set; }
        public int MaKH { get; set; }
    }
}